/// filename: main.c
/// 
/// Purpose: to demonstrate global variable fuzzing at a super light level

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/// globals

static int c09_global_var = 67;

/// MAIN FUNCTION

int main()
{
    if(c09_global_var == 10)
    {
        char input[6] = "Hello";
        char buffer[1];
        strcpy(buffer, input); /// ./test_lib/small/test_files/main.c:22: High: strcpy
    }

    return 0;
}